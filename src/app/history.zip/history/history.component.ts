import { Component, OnInit,Output } from '@angular/core';
import {Request} from '../request';
@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
//@Output() request:any;

  constructor() { }
request:Array<Request>;
  ngOnInit() {
    this.request=x;
    console.log(this.request);
  }

}
const x=[{requestId:1,requestby:"ABC",location:"Noida",building:"A",floor:5,seats:40,status:"true"},
{requestId:2,requestby:"ABC",location:"Noida",building:"A",floor:5,seats:40,status:"true"},
{requestId:3,requestby:"ABC",location:"Noida",building:"A",floor:5,seats:40,status:"true"},
{requestId:4,requestby:"ABC",location:"Noida",building:"A",floor:5,seats:40,status:"true"},
{requestId:5,requestby:"ABC",location:"Noida",building:"A",floor:5,seats:40,status:"true"}

]